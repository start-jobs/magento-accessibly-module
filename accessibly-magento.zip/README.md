# Magento Accessibly Extension

Add [Accessibly](https://accessiblyapp.com) widget to your Magento 2 site.

### Installation

* `composer require on_the_map/accessibly`
* `php bin/magento module:enable Onthemap_Accessibly`
* `php bin/magento setup:upgrade`
* `php bin/magento setup:di:compile`
* `php bin/magento setup:static-content:deplo`
* `php bin/magento cache:clean`
